<?php
if (!defined('WORDFENCE_VERSION')) { exit; }
/**
 * Presents the overlay.
 */
?>
<div id="wf-onboarding-tour-overlay" style="display: none;">
	
</div>
